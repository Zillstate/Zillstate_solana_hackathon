<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$conn = new mysqli("localhost", "root", "", "rental_db");
if (mysqli_connect_error()) {
    echo json_encode(["error" => mysqli_connect_error()]);
    exit();
}

$eData = file_get_contents("php://input");
$dData = json_decode($eData, true);

// Extract filter data from request
$location = $dData['location'] ?? "";
$spaceType = $dData['spaceType'] ?? "";
$price = $dData['price'] ?? "";
$duration = $dData['duration'] ?? "";
$response = [];

// Create SQL query based on filters
$sql = "SELECT * FROM rentals WHERE 1=1";

// Append conditions based on the received filter values
if ($location != "") {
    $sql .= " AND location LIKE '%" . $conn->real_escape_string($location) . "%'";
}
if ($spaceType != "") {
    $sql .= " AND space_type = '" . $conn->real_escape_string($spaceType) . "'";
}
if ($price != "") {
    if ($price == "low") {
        $sql .= " AND price < 500";  // Example price range for 'low'
    } elseif ($price == "medium") {
        $sql .= " AND price BETWEEN 500 AND 1000";  // Example price range for 'medium'
    } elseif ($price == "high") {
        $sql .= " AND price > 1000";  // Example price range for 'high'
    }
}
if ($duration != "") {
    $sql .= " AND duration = '" . $conn->real_escape_string($duration) . "'";
}

// Execute the query
$res = $conn->query($sql);

// Check if any rentals match the filters
if ($res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        $response[] = $row;  // Add each matching rental to the response
    }
} else {
    $response["result"] = "No rentals found with the applied filters.";
}

$conn->close();
echo json_encode($response);
?>
